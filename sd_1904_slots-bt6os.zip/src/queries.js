import { HttpError } from 'wasp/server'

export const getUser = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  const userId = context.user.id;
  const user = await context.entities.User.findUnique({
    where: { id: userId },
    include: {
      transactions: true,
      games: true
    }
  });
  if (!user) throw new HttpError(404, 'User not found');
  return user;
}

export const getTransactions = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }
  return context.entities.Transaction.findMany({ where: { userId: context.user.id } });
}

export const getGames = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Game.findMany({
    where: {
      userId: context.user.id
    }
  })
}