import { HttpError } from 'wasp/server'

export const createTransaction = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const user = await context.entities.User.findUnique({
    where: { id: context.user.id }
  });

  const newBalance = user.balance + args.amount;

  const newTransaction = await context.entities.Transaction.create({
    data: {
      amount: args.amount,
      user: { connect: { id: context.user.id } }
    }
  });

  await context.entities.User.update({
    where: { id: context.user.id },
    data: { balance: newBalance }
  });

  return newTransaction;
}

export const playGame = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const result = Math.random() >= 0.04 ? Math.floor(Math.random() * 100) : -Math.floor(Math.random() * 100);
  const newGame = await context.entities.Game.create({ data: { result, userId: context.user.id } });

  const user = await context.entities.User.findUnique({ where: { id: context.user.id } });
  const updatedBalance = user.balance + result;

  await context.entities.User.update({ where: { id: context.user.id }, data: { balance: updatedBalance } });

  return newGame;
}