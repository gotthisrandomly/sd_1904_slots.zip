import React, { useState } from 'react';
import { useAction, createTransaction } from 'wasp/client/operations';
import { Link } from 'react-router-dom';

const PaymentPage = () => {
  const createTransactionFn = useAction(createTransaction);
  const [amount, setAmount] = useState(0);

  const handleCreateTransaction = () => {
    createTransactionFn({ amount });
    setAmount(0);
  };

  return (
    <div className='p-4'>
      <input
        type='number'
        placeholder='Enter amount'
        className='px-1 py-2 border rounded text-lg'
        value={amount}
        onChange={(e) => setAmount(parseFloat(e.target.value))}
      />
      <button
        onClick={handleCreateTransaction}
        className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-4'
      >
        Load Account
      </button>
    </div>
  );
}

export default PaymentPage;