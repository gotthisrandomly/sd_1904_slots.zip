import React from 'react';
import { useAction, playGame } from 'wasp/client/operations';
import { Link } from 'react-router-dom';

const Game = () => {
  const playGameFn = useAction(playGame);

  const handlePlayGame = () => {
    playGameFn({});
  };

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Slot Machine Game</h1>
      <button
        onClick={handlePlayGame}
        className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'
      >
        Play Game
      </button>
      <Link to='/dashboard' className='block mt-4 text-blue-500 hover:underline'>Go to Dashboard</Link>
    </div>
  );
}

export default Game;