import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery, getUser, getTransactions, getGames } from 'wasp/client/operations';

const DashboardPage = () => {
  const { data: user, isLoading: userLoading, error: userError } = useQuery(getUser);
  const { data: transactions, isLoading: transactionsLoading, error: transactionsError } = useQuery(getTransactions);
  const { data: games, isLoading: gamesLoading, error: gamesError } = useQuery(getGames);

  if (userLoading || transactionsLoading || gamesLoading) return 'Loading...';
  if (userError || transactionsError || gamesError) return 'Error: ' + (userError || transactionsError || gamesError);

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Account Dashboard</h1>
      <div className='mb-4'>
        <p><span className='font-bold'>Balance:</span> ${user.balance}</p>
      </div>
      <div className='mb-4'>
        <h2 className='text-lg font-bold'>Transactions</h2>
        {transactions.map((transaction) => (
          <div key={transaction.id} className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'>
            <div>${transaction.amount}</div>
          </div>
        ))}
      </div>
      <div>
        <h2 className='text-lg font-bold'>Games</h2>
        {games.map((game) => (
          <div key={game.id} className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'>
            <div>${game.result}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default DashboardPage;