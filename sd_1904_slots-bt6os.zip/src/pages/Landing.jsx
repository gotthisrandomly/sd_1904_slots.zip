import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from 'wasp/client/operations';
import { getUser, getGames } from 'wasp/client/operations';

const LandingPage = () => {
  const { data: user } = useQuery(getUser);
  const { data: games } = useQuery(getGames);

  return (
    <div className='p-4'>
      <h1>Welcome to our Casino Website!</h1>
      <p>Feel the excitement of our online casino games.</p>
      <div>
        <h2>Your Account Details:</h2>
        <p>Username: {user.username}</p>
        <p>Balance: {user.balance}</p>
      </div>
      <div>
        <h2>Available Games:</h2>
        {games.map((game) => (
          <div key={game.id}>
            <p>{game.name}</p>
            <p>Winning Odds: {game.odds}</p>
          </div>
        ))}
      </div>
      <Link to='/game' className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-4'>Play Slot Machine</Link>
    </div>
  );
}

export default LandingPage;